﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ejer_47;

namespace console47
{
    class Program
    {
        static void Main(string[] args)
        {
            Torneo<Equipo> torneoBasquet = new Torneo<Equipo>("torneo Basquet");
            Torneo<Equipo> torneoFutbol = new Torneo<Equipo>("torneo futbol");

            Equipofutbol e1 = new Equipofutbol("independiente",DateTime.Now);
            Equipofutbol e2 = new Equipofutbol("boca", DateTime.Now);
            Equipofutbol e3 = new Equipofutbol("river", DateTime.Now);

            EquipoBasquet b1 = new EquipoBasquet("lakers", DateTime.Now);
            EquipoBasquet b2 = new EquipoBasquet("redbulls", DateTime.Now);
            EquipoBasquet b3 = new EquipoBasquet("chicagoFire", DateTime.Now);

            string partido;

            torneoFutbol += e1;
            torneoFutbol += e2;
            torneoFutbol += e3;

            torneoBasquet += b1;
            torneoBasquet += b2;
            torneoBasquet += b3;


            Console.WriteLine(torneoBasquet.mostrar());

            Console.WriteLine(torneoFutbol.mostrar());

            Console.WriteLine("Partidos de futbol:");
            partido = torneoFutbol.jugarPartido;
            Console.WriteLine("{0}", partido);
            partido = torneoFutbol.jugarPartido;
            Console.WriteLine("{0}", partido);
            partido = torneoFutbol.jugarPartido;
            Console.WriteLine("{0}", partido);

            Console.WriteLine("Partidos de basquet:");
            partido = torneoBasquet.jugarPartido;
            Console.WriteLine("{0}", partido);
            partido = torneoBasquet.jugarPartido;
            Console.WriteLine("{0}", partido);
            partido = torneoBasquet.jugarPartido;
            Console.WriteLine("{0}", partido);

            Console.ReadKey();
        }
    }
}
