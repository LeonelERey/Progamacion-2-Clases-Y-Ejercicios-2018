﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejer_47
{
    public abstract class Equipo
    {
        private string nombre;
        private DateTime fechaCreacion;

        public string Nombre
        {
            get
            {
                return this.nombre;       
            }
        }
        public DateTime FechaCreacion
        {
            get
            {
                return this.fechaCreacion;
            }
        }
        public Equipo(string nombre)
        {
            this.nombre = nombre;
        }
        public Equipo(string nombre,DateTime fecha):this(nombre)
        {
            this.fechaCreacion = fecha;
        }
        public static bool operator ==(Equipo e1,Equipo e2)
        {
            bool retorno=false;

            if(e1.nombre==e2.nombre&&e1.fechaCreacion==e2.fechaCreacion)
            {
                retorno = true;
            }

            return retorno;
        }
        public static bool operator !=(Equipo e1, Equipo e2)
        {
            return !(e1 == e2);
        }
        public string ficha(Equipo equipo)
        {
            string retorno = " ";

            if(!(equipo is null))
            {
                retorno = string.Format($"{equipo.Nombre} fundado en {equipo.FechaCreacion}");
            }

            return retorno;
        }

    }
}
