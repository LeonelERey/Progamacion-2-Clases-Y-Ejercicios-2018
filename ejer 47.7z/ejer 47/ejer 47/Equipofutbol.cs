﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejer_47
{
    public class Equipofutbol : Equipo
    {
        public Equipofutbol(string nombre,DateTime fecha):base(nombre,fecha)
        {

        }
    }
}
