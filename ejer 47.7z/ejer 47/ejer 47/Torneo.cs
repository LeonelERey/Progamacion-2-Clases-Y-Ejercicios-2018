﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejer_47
{
    public class Torneo<T> where T : Equipo
    {
        public string nombre;
        public List<T> equipos;

        public Torneo()
        {
            this.equipos = new List<T>();
        }
        public Torneo(string nombre):this()
        {
            this.nombre = nombre;
        }
        public static bool operator == (Torneo<T> torneo, T equipo)
        {
            bool retorno=false;

            if(!(equipo is null)&& !(torneo is null))
            {
                foreach(T item in torneo.equipos)
                {
                    if(item == equipo)
                    {
                        retorno = true;
                    }
                }
            }

            return retorno;
        }
        public static bool operator !=(Torneo<T> torneo, T equipo)
        {
            return !(torneo == equipo);
        }
        public static Torneo<T> operator +(Torneo<T> torneo,T equipo)
        {
            if(torneo!=equipo)
            {
                torneo.equipos.Add(equipo);
            }

            return torneo;
        }
        public string calcularPartido(T equipo1, T equipo2)
        {
            string retorno = " ";
            Random r = new Random();

            if(!(equipo1 is null)&&!(equipo2 is null))
            {
                retorno = string.Format($"{equipo1.Nombre} {r.Next(0, 5)} - {r.Next(0, 5)} {equipo2.Nombre}");
            }

            return retorno;
        }
        public string jugarPartido
        {
            get
            {
                Random r = new Random();

                return this.calcularPartido(this.equipos[r.Next(0,this.equipos.Count)], this.equipos[r.Next(0, this.equipos.Count)]);
            }
        }
        public string mostrar()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("\n{0}\n",nombre);
            foreach(T item in equipos)
            {
                sb.AppendFormat("Nombre:{0}  Fecha de cracion:{1}", item.Nombre, item.FechaCreacion);
            }

            return sb.ToString();
        }

    }

}
