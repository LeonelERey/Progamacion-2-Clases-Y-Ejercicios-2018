using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;

namespace GuiFormulario
{
    public partial class FrmSirviente : Form
    {
        public FrmSirviente()
        {
            InitializeComponent();
        }

        private void btnCrear_Click(object sender, EventArgs e)
        {
        int energia = int.Parse(txtEnergia.Text);
      string codigoString = nudCodigo.ToString();
      int codigoInt = int.Parse(codigoString);
      RobotSirviente robot = new RobotSirviente(energia, txtOrigen.Text);
      MessageBox.Show(robot.ServirHumanidad());      

        }

    private void FrmSirviente_Load(object sender, EventArgs e)
    {

    }

    
  }
}
