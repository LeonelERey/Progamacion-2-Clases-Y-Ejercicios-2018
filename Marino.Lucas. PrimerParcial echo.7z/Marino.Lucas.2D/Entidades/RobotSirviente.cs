using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class RobotSirviente : Robot
    {
    public RobotSirviente()
    {
      
    }

    public RobotSirviente(int energia, string origen) : this()
    {
      base.energia = energia;
      base.origen = origen;
    }

    public override bool CargarEnergia (int energia)
    {
      if (base.Energia == 0)
      {
        base.energia = energia;
        return true;
      }
      else
        return false;
    }

    public override string ServirHumanidad()
    {
      bool bandera = false;
      if (base.Energia > 0)
      {
        base.energia--;
        bandera = true;
      }
      StringBuilder sb = new StringBuilder();

      if (bandera == true)
      {
        sb.AppendFormat($"Haciendo masajes...\n");
      }
      else
      {
        sb.AppendFormat($"[{base.Codigo}] Sin energia\n");
      }
      return sb.ToString();
    }








  }
}
