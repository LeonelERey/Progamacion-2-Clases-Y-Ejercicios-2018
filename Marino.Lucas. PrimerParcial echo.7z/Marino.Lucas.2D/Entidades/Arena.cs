using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
  public class Arena
  {
    public int espacioDisponible;
    public string nombre;
    public List<RobotDeCombate> robotsDeCombate;
    public List<RobotSirviente> robotsSirvientes;

    private Arena()
    { }

    public Arena(string nombre, int espacioDisponible)
    {
      this.nombre = nombre;
      this.espacioDisponible = espacioDisponible;
    }

    public string Combate(RobotDeCombate combatiente)
    {
      bool encontroContrincante = false;
      StringBuilder sb = new StringBuilder();
      RobotDeCombate auxRobotElejido = null;
      if (combatiente != null && combatiente.Energia > 0)
      {
        foreach (RobotDeCombate robotElejido in robotsDeCombate)
        {
          if (robotElejido.Energia > 0)
          {
            auxRobotElejido = robotElejido;
            encontroContrincante = true;
            break;
          }
        }

        if (encontroContrincante == true)
        {
          sb.AppendFormat($"{combatiente.ServirHumanidad()} \n\n {auxRobotElejido.ServirHumanidad()}");
          if (combatiente.CaballosDeFuerza > auxRobotElejido.CaballosDeFuerza)
          {
            sb.AppendFormat($"\n\nCodigo del Ganador: {combatiente.Codigo}");
          }
          else if (combatiente.CaballosDeFuerza < auxRobotElejido.CaballosDeFuerza)
          {
            sb.AppendFormat($"\n\nCodigo del Ganador: {auxRobotElejido.Codigo}");
          }
          else
          {
            sb.AppendFormat($"\n\nSE HA DECLARADO UN EMPATE!");
          }
        }
        else
        {
          sb.AppendFormat($"\n\nNo se encontro oponente");
        }

      }
      return sb.ToString();
    }

    public string ServirEspectadores()
    {
      StringBuilder sb = new StringBuilder();
      foreach (RobotSirviente robotElejido in robotsSirvientes)
      {
        if (robotElejido.Energia > 0)
        {
          sb.AppendFormat($"{robotElejido.ServirHumanidad()}");
          break;
        }
        else
          sb.AppendFormat(" ");
      }
      return sb.ToString();
    }

    public override string ToString()
    {
      StringBuilder sb = new StringBuilder();
      sb.AppendFormat($"Nombre de la arena: {this.nombre}");
      sb.AppendFormat($"\n\nLISTADO ROBOTS DE COMBATE\n");
      foreach (RobotDeCombate robot in robotsDeCombate)
      {
        sb.AppendFormat($"\n{robot.ServirHumanidad()}");
      }
      sb.AppendFormat($"\n\nLISTADO DE ROBOTS SIRVIENTES\n");
      foreach (RobotSirviente robot in robotsSirvientes)
      {
        sb.AppendFormat($"\n{robot.ServirHumanidad()}");
      }
      return sb.ToString();
    }


    public static implicit operator string(Arena arena)
    {
      return arena.ToString();
    }

    public static bool operator ==(Arena arena, Robot robot)
    {
      bool retorno = false;
      if (arena != null && robot != null)
      {
        foreach (Robot item in arena.robotsDeCombate)
        {
          if (item == robot)
          {
            retorno = true;
            break;
          }
        }
        if (retorno == false)
        {
          foreach (Robot item in arena.robotsSirvientes)
            if (item == robot)
            {
              retorno = true;
              break;
            }
        }
      }
      return retorno;
    }

    public static bool operator !=(Arena arena, Robot robot)
    {
      return !(arena == robot);
    }

    public static Arena operator +(Arena arena, Robot robot)
    {
      bool esta = false;
      if (robot is RobotDeCombate)
      {
        foreach(RobotDeCombate auxRobot in arena.robotsDeCombate)
        {
          if (auxRobot == robot)
          {
            esta = true;
            break;
          }
        }
        if (esta == true)
          arena.robotsDeCombate.Add((RobotDeCombate)robot);
      }
      else if (robot is RobotSirviente)
      {
        foreach (RobotSirviente auxRobot in arena.robotsSirvientes)
        {
          if (auxRobot == robot)
          {
            esta = true;
            break;
          }
        }
        if (esta == true)
          arena.robotsSirvientes.Add((RobotSirviente)robot);
      }
      return arena;
    }


    public static Arena operator -(Arena arena, Robot robot)
    {
      bool esta = false;
      if (robot is RobotDeCombate)
      {
        foreach (RobotDeCombate auxRobot in arena.robotsDeCombate)
        {
          if (auxRobot == robot)
          {
            esta = true;
            break;
          }
        }
        if (esta == true)
          arena.robotsDeCombate.Remove((RobotDeCombate)robot);
      }
      else if (robot is RobotSirviente)
      {
        foreach (RobotSirviente auxRobot in arena.robotsSirvientes)
        {
          if (auxRobot == robot)
          {
            esta = true;
            break;
          }
        }
        if (esta == true)
          arena.robotsSirvientes.Remove((RobotSirviente)robot);
      }
      return arena;
    }
  }
}
