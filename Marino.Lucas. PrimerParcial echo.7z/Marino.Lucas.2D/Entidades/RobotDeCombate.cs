using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class RobotDeCombate : Robot
    {
    private bool lucho;
    private int caballosDeFuerza;

    public bool Lucho
    {
      get { return this.lucho; }
    }

    public int CaballosDeFuerza
    {
      get { return this.caballosDeFuerza; }
    }

    public override string ServirHumanidad()
    {
      bool bandera = false;
      if (base.Energia > 0)
      {
        base.energia--;
        bandera = true;
      }
      StringBuilder sb = new StringBuilder();
      
      if (bandera == true)
      {
        sb.AppendFormat($"Robot De combate [{base.Codigo}] - Disparando misiles...\n");
      }
      else
      {
        sb.AppendFormat($"Robot De combate [{base.Codigo}] - Sin energia\n");
      }
      return sb.ToString();
    }

    public RobotDeCombate()
    {
      this.lucho = false;
    }

    public RobotDeCombate(int energia, string origen) : this()
    {
      base.energia = energia;
      base.origen = origen;
    }

    public RobotDeCombate(int energia, string origen, int caballosDeFuerza) : this(energia, origen)
    {
      this.caballosDeFuerza = caballosDeFuerza;
    }

    }
}
