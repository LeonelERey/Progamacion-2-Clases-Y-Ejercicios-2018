using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class Robot
    {
    protected static int capacidadEnergia;
    private int codigo;
    private static int contador;
    protected int energia;
    protected string origen;

    //Esto es lo unico que no me funciona :(
    public int CapacidadEnergia
    {
      get
      { return capacidadEnergia; }
    }

    public int Codigo
    {
      get { return this.codigo; }
    }

    public int Energia
    {
      get { return this.energia; }
    }

    static Robot()
    {
      capacidadEnergia = 50;
      contador = 0;
    }

    protected Robot()
    {
      this.origen = "Coreano";
      this.energia = 10;
      contador++;
      contador = this.codigo;
    }

    public Robot (int energia, string origen) : this ()
    {
      this.energia = energia;
      this.origen = origen;
    }

    public virtual bool CargarEnergia(int energia)
    {
      if (energia > 0 && energia < capacidadEnergia)
      {
        this.energia = energia;
        return true;
      }
      else
      {
        return false;
      }

    }

    public abstract string ServirHumanidad();

    public static bool operator ==(Robot robot1, Robot robot2)
    {
      bool retorno = false;
      if (robot1 != null && robot2 != null && robot1 == robot2)
      {
        retorno = true;
      }
      return retorno;
    }

    public static bool operator !=(Robot robot1, Robot robot2)
    {
      return !(robot1 == robot2);
    }

    /*public string ToString()
    {

    }*/


    }
}
