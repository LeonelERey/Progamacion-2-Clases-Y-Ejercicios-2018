using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
  class Alumno : Persona
  {
    private short anio;
    private Diviciones divicion;

    public string anioDivicion
    {
      get
      {
        return this.anio.ToString() +"º"+ this.divicion.ToString();
      }
    }
    public Alumno(string nombre,string apellido,string documento,short anio,Diviciones divicion):base(nombre,apellido,documento)
    {
      anio = this.anio;
      divicion = this.divicion;
    }
    public override string exponerDatos()
    {
      return base.exponerDatos()+anio.ToString()+"º"+divicion.ToString();
    }
    public override bool validarDocumento(string doc)
    {
      bool retorno=false;
      doc.ToCharArray();
      if(doc[2]=='-'&& doc[7] == '-')
      {
        for(int i=0;i<9;i++)
        {
          if(Convert.ToInt32(doc[i])/Convert.ToInt32(doc[i])==1)
          {
            if(i==2||i==7)
            {
              i++;
            }
            if(i==8)
            {
              retorno = true;
            }
          }
          else
          {
            break;
          }
        }
      }
      return retorno;
    }
  }
}
