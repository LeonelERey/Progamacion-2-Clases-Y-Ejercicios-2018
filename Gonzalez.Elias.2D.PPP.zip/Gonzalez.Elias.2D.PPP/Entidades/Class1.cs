using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
  enum Diviciones
  {
    A,
    B,
    C,
    D,
    E
  }
  public class class1
  {
  }
}
