using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
  public abstract class Persona
  {
    private string nombre;
    private string apellido;
    private string documento;

    public string Apellido
    {
      get
      {
        return this.apellido;
      }
    }
    public string Nombre
    {
      get
      {
        return this.nombre;
      }
    }
    public string Documento
    {
      get
      {
        return this.apellido;
      }
      set
      {
        this.documento = value;
      }
    }
    public virtual string exponerDatos()
    {
      StringBuilder datos = new StringBuilder();

      datos.AppendFormat("Nombre:{0} \nApellido:{1} \nDocumento:{2}",this.nombre, this.apellido, this.documento );

      return datos.ToString();
    }
    public Persona (string nombre,string apellido,string documento)
    {
      this.nombre = nombre;
      this.apellido = apellido;
      this.documento = documento;
    }

    public abstract bool validarDocumento(string doc);

  }
}
