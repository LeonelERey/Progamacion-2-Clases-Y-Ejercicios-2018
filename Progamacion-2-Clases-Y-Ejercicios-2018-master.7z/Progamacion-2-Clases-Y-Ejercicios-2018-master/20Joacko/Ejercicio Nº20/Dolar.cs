using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Billetes 
{
  class Dolar
  {
    public double cantidad;
    private static float ContizResPectDolar  =(float)1;
  }
}
