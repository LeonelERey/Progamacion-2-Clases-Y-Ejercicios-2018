using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Billetes;

namespace Ejercicio_Nº20
{
  class Program
  {
    static void Main(string[] args)
    {
            double cantidad;
            double cantidadP;
            double cantidadD;
            bool validar;

            Peso peso = new Peso(1);
          
            Peso Peso2 = new Peso(0);
            Dolar dolar = new Dolar();
            Euro euro = new Euro();

            dolar.cantidad = 1;
            euro.cantidad = 5;
            cantidadD = dolar.cantidad;
            cantidadP = peso.GetCantidad();


            Console.WriteLine("Peso es:{0}, Dolar es: {1}", cantidadP,cantidadD);
            // Peso2 = peso - dolar;

            validar = peso == dolar;
            if (validar==true)
            {
                Console.WriteLine("\n Son iguales");
            }
            else
            {
                Console.WriteLine("\n no soon iguales");
            }
            cantidad = Peso2.GetCantidad();

            Console.WriteLine("La suma es:{0}",cantidad );


            
             Console.ReadKey();
           /* peso = Peso2 + dolar;
           

             
            Console.Title = "Ejercicio Numero 20";*/
          

            


    }
  }
}
