using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Billetes
{
     class Peso
    {
        private double cantidad;
        private static float ContizResPectDolar = (float)17.55;

        private Peso()
        {

        }

        public Peso(double cant)
        {
            this.cantidad = cant;

        }

        public Peso(double cant, float cot)
        {
            this.cantidad = cant;
            ContizResPectDolar = cot;


        }



        public static Peso operator +(Peso peso, Dolar dolar)
        {
            peso.cantidad += (dolar.cantidad * (ContizResPectDolar));
            return peso;
        }

        public static Peso operator +(Peso peso, Euro euro)
        {
            peso.cantidad += ((euro.cantidad * 1.3642) * (ContizResPectDolar));
            return peso;
        }
        //******************************************
        public static Peso operator -(Peso peso, Dolar dolar)
        {
            peso.cantidad -= (dolar.cantidad * (ContizResPectDolar));
            return peso;
        }

        public static Peso operator -(Peso peso, Euro euro)
        {
            peso.cantidad -= ((euro.cantidad * 1.3642) * (ContizResPectDolar));
            return peso;
        }

        public static bool operator ==(Peso peso, Euro euro)
        {
            bool retorno;
            if (peso is null || euro is null)
            {
                retorno = false;
            }
            else
            {
                if (peso.cantidad == ((euro.cantidad * 1.3642) * (ContizResPectDolar)))
                {
                    retorno = true;
                }
                else
                {
                    retorno = false;
                }
            }
            return retorno;

        }
        public static bool operator !=(Peso peso, Euro euro)
        {
            return !(peso == euro);
        }
        //*********************************************************************************
        public static bool operator ==(Peso peso, Dolar dolar)
        {
            bool retorno;
            if (peso is null || dolar is null)
            {
                retorno = false;
            }
            else
            {
                if (peso.cantidad == ((dolar.cantidad) * (ContizResPectDolar)))
                {
                    retorno = true;
                }
                else
                {
                    retorno = false;
                }
            }
            return retorno;

        }
        public static bool operator !=(Peso peso, Dolar dolar)
        {
            return !(peso == dolar);
        }

        public double GetCantidad()
        {
            return this.cantidad;
        }
        public float GetCotizacion()
        {
            return ContizResPectDolar;
        }

        public static explicit operator Dolar(Peso peso)
        {
            Dolar retorno = new Dolar();
            retorno.cantidad = peso.cantidad * ContizResPectDolar;
            return retorno;
        }

        public static explicit operator Euro(Peso peso)
        {
            Euro retorno = new Euro();
            retorno.cantidad = peso.cantidad * (ContizResPectDolar * 1.3642);
            return retorno;
        }

        public static explicit operator Peso(double peso)
        {
            Peso p = new Peso();
            p.cantidad = peso;

            return p;
        } 
        

    }
}
