using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Billetes
{
  class Dolar
  {
    private double cantidad;
    private static float cotizRespectoDolar = (float)1;
    public Dolar()
    {

    }
    public Dolar(double cant)
    {
      this.cantidad = cant;
    }
    public Dolar(double cant, float cotiz)
    {
      this.cantidad = cant;
      cotizRespectoDolar = cotiz;
    }
    public double GetCantidad()
    {
      return this.cantidad;
    }
    public float GetCotizacion()
    {
      return cotizRespectoDolar;
    }
    public static explicit operator Pesos(Dolar dolar)
    {
      double resp = dolar.cantidad * 17.55;
      Pesos retorno = new Pesos(resp);

      return retorno;
    }
    public static explicit operator Euro(Dolar dolar)
    {
      double resp = dolar.cantidad * 1.3642;
      Euro retorno = new Euro(resp);

      return retorno;
    }
    public static implicit operator Dolar(double dolar)
    {
      Dolar retorno = new Dolar();
      retorno.cantidad = dolar;

      return retorno;
    }
    public static Pesos operator +(Dolar dolar, Pesos peso)
    {
      double pes = peso.GetCantidad();
      dolar.cantidad += Math.Round((pes/17.55),2);
      return peso;
    }

    public static Dolar operator +(Dolar dolar, Euro euro)
    {
      double euDol = euro.GetCantidad() * 1.3642;
      dolar.cantidad += euDol;
      return dolar;
    }
    //******************************************
    public static Dolar operator -(Dolar dolar, Pesos peso)
    {
      double pes = peso.GetCantidad();
      dolar.cantidad -= Math.Round((pes*17.55),2);
      return dolar;
    }

    public static Dolar operator -(Dolar dolar,Euro euro)
    {
      double eur = euro.GetCantidad();
      dolar.cantidad -=Math.Round( (eur * (1.6342)),2);
      return dolar;
    }

    public static bool operator ==(Dolar dolar, Pesos peso)
    {
      bool retorno;
      if (peso is null || dolar is null)
      {
        retorno = false;
      }
      else
      {
        double pes = peso.GetCantidad();
        double pesDolar = Math.Round((pes/17.55), 2);
        if (dolar.cantidad == pesDolar)
        {
          retorno = true;
        }
        else
        {
          retorno = false;
        }
      }
      return retorno;

    }
    public static bool operator !=(Dolar dolar,Pesos peso)
    {
      return !(peso == dolar);
    }

    //*********************************************************************************
    public static bool operator ==(Dolar dolar,Euro euro )
    {
      bool retorno;
      if (euro is null || dolar is null)
      {
        retorno = false;
      }
      else
      {
        double eur= euro.GetCantidad();
        double dolEu = Math.Round(eur / 1.6342, 2);
        if (dolar.cantidad == dolEu)
        {
          retorno = true;
        }
        else
        {
          retorno = false;
        }
      }
      return retorno;

    }
    public static bool operator !=(Dolar dolar, Euro euro)
    {
      return !(dolar == euro);
    }
      
    
    //*********************************************************************************
    public static bool operator ==(Dolar dolar1, Dolar dolar2)
    {
      bool retorno;
      if (dolar1 is null || dolar2 is null)
      {
        retorno = false;
      }
      else
      {

        if (dolar1.cantidad == dolar2.cantidad)
        {
          retorno = true;
        }
        else
        {
          retorno = false;
        }
      }
      return retorno;

    }
    public static bool operator !=(Dolar dolar1, Dolar dolar2)
    {
      return !(dolar1 == dolar2);
    }
    

  }
}

