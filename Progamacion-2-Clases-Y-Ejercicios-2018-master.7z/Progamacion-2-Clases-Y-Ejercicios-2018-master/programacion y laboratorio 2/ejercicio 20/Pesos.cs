using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Billetes

{
  class Pesos
  {
    private double cantidad;
    private static float cotizRespectoDolar=(float)17.55;

    public Pesos()
    {

    }
    public Pesos(double cant)
    {
      this.cantidad = cant;
    }
    public Pesos(double cant, float cotiz)
    {
      this.cantidad = cant;
      cotizRespectoDolar = cotiz;
    }

    public double GetCantidad()
    {
      return this.cantidad;
    }
    public float GetCotizacion()
    {
      return cotizRespectoDolar;
    }
    public static explicit operator Dolar (Pesos peso)
    {
      double resp = peso.cantidad * cotizRespectoDolar;
      Dolar retorno = new Dolar(resp);
      
      return retorno;
    }
    public static explicit operator Euro(Pesos peso)
    {
      double resp = peso.cantidad * (cotizRespectoDolar*1.3642);
      Euro retorno = new Euro(resp);

      return retorno;
    }
    public static implicit operator Pesos(double peso)
    {
      Pesos retorno = new Pesos();
      retorno.cantidad = peso;

      return retorno;
    }
    public static Pesos operator +(Pesos peso, Dolar dolar)
    {
      double dol=dolar.GetCantidad();
      peso.cantidad += (dol * (cotizRespectoDolar)); 
      return peso;
    }

    public static Pesos operator +(Pesos peso, Euro euro)
    {
      double eur = euro.GetCantidad()*1.3642;
      peso.cantidad += (eur* (cotizRespectoDolar));
      return peso;
    }
    //******************************************
    public static Pesos operator -(Pesos peso, Dolar dolar)
    {
      double dol = dolar.GetCantidad();
      peso.cantidad -= (dol * (cotizRespectoDolar));
      return peso;
    }

    public static Pesos operator -(Pesos Peso, Euro euro)
    {
      double eur = euro.GetCantidad() * 1.3642;
      Peso.cantidad -= (eur * (cotizRespectoDolar));
      return Peso;
    }

    public static bool operator ==(Pesos peso, Euro euro)
    {
      bool retorno;
      if (peso is null || euro is null)
      {
        retorno = false;
      }
      else
      {
        double eur = euro.GetCantidad() * 1.3642;
        double eurPeso =Math.Round( (eur * cotizRespectoDolar),2);
        if (peso.cantidad == (eurPeso))
        {
          retorno = true;
        }
        else
        {
          retorno = false;
        }
      }
      return retorno;

    }
    public static bool operator !=(Pesos peso, Euro euro)
    {
      return !(peso == euro);
    }
    //*********************************************************************************
    public static bool operator ==(Pesos peso, Dolar dolar)
    {
      bool retorno;
      if (peso is null || dolar is null)
      {
        retorno = false;
      }
      else
      {
        double dol = dolar.GetCantidad();
        double dolPesos = Math.Round(dol * (cotizRespectoDolar), 2);
        if (peso.cantidad == dolPesos)
        {
          retorno = true;
        }
        else
        {
          retorno = false;
        }
      }
      return retorno;

    }
    public static bool operator !=(Pesos peso, Dolar dolar)
    {
      return !(peso == dolar);
    }
    //*********************************************************************************
    public static bool operator ==(Pesos peso1,Pesos peso2)
    {
      bool retorno;
      if (peso1 is null || peso2 is null)
      {
        retorno = false;
      }
      else
      {
        
        if (peso1.cantidad == peso2.cantidad)
        {
          retorno = true;
        }
        else
        {
          retorno = false;
        }
      }
      return retorno;

    }
    public static bool operator !=(Pesos peso1, Pesos peso2)
    {
      return !(peso1 == peso2);
    }

  }
}
