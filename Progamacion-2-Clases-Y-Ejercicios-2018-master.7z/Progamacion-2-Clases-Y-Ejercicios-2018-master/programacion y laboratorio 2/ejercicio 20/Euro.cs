using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Billetes
{
  class Euro
  {
    private double cantidad;
    private static float cotizRespectoDolar = (float)1.3642;
    public Euro()
    {

    }
    public Euro(double cant)
    {
      this.cantidad = cant;
    }
    public Euro(double cant, float cotiz)
    {
      this.cantidad = cant;
      cotizRespectoDolar = cotiz;
    }
    public double GetCantidad()
    {
      return this.cantidad;
    }
    public float GetCotizacion()
    {
      return cotizRespectoDolar;
    }
    public static explicit operator Pesos(Dolar dolar)
    {
      double resp = dolar.cantidad * 17.55;
      Pesos retorno = new Pesos(resp);

      return retorno;
    }
    public static explicit operator Euro(Dolar dolar)
    {
      double resp = dolar.cantidad * 1.3642;
      Euro retorno = new Euro(resp);

      return retorno;
    }
    public static implicit operator Dolar(double dolar)
    {
      Dolar retorno = new Dolar();
      retorno.cantidad = dolar;

      return retorno;
    }
    public static Pesos operator +(Dolar dolar, Pesos peso)
    {
      double pes = peso.GetCantidad();
      dolar.cantidad += Math.Round((pes / 17.55), 2);
      return peso;
    }

    public static Dolar operator +(Dolar dolar, Euro euro)
    {
      double euDol = euro.GetCantidad() * 1.3642;
      dolar.cantidad += euDol;
      return dolar;
    }
    //******************************************
    public static Dolar operator -(Euro euro, Pesos peso)
    {
      double pes = peso.GetCantidad();
      dolar.cantidad -= Math.Round((pes * 17.55), 2);
      return dolar;
    }

    public static Euro operator -(Euro euro,Dolar dolar )
    {
      double dol = dolar.GetCantidad();
      euro.cantidad -= Math.Round((dol / (1.6342)), 2);
      return dolar;
    }

    public static bool operator ==(Euro euro, Pesos peso)
    {
      bool retorno;
      if (peso is null || euro is null)
      {
        retorno = false;
      }
      else
      {
        double pes = peso.GetCantidad();
        double pesEu = Math.Round(((pes / 17.55)/1.6342), 2);
        if (euro.cantidad == pesEu)
        {
          retorno = true;
        }
        else
        {
          retorno = false;
        }
      }
      return retorno;

    }
    public static bool operator !=(Euro euro, Pesos peso)
    {
      return !(peso == euro);
    }

    //*********************************************************************************
    public static bool operator ==(Euro euro,Dolar dolar )
    {
      bool retorno;
      if (euro is null || dolar is null)
      {
        retorno = false;
      }
      else
      {
        double dol= dolar.GetCantidad();
        double dolEu = Math.Round(dol / 1.6342, 2);
        if (euro.cantidad == dolEu)
        {
          retorno = true;
        }
        else
        {
          retorno = false;
        }
      }
      return retorno;

    }
    public static bool operator !=(Euro euro,Dolar dolar )
    {
      return !(dolar == euro);
    }


    //*********************************************************************************
    public static bool operator ==(Euro euro1, Euro euro2)
    {
      bool retorno;
      if (euro1 is null || euro2 is null)
      {
        retorno = false;
      }
      else
      {

        if (euro1.cantidad == euro2.cantidad)
        {
          retorno = true;
        }
        else
        {
          retorno = false;
        }
      }
      return retorno;

    }
    public static bool operator !=(Euro euro1, Euro euro2)
    {
      return !(euro1 == euro2);
    }
  }
}
