﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace programacion_y_laboratorio_2
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Persona persona01 = new Persona();

            persona01.nombre = Console.ReadLine();
            persona01.dni = 41234588;
            
            Persona persona02 = new Persona();

            persona02.nombre = Console.ReadLine();
            persona02.dni = 41252688;

            persona01.Mostrar(persona01);
            persona02.Mostrar(persona02);

            Console.Read();*/

            Automovil.MostrarCantidadRuedas();
            Console.Read();


        }
    }
}
/*========== CLASE 02 ========== 

* POO(programacion orientada a objetos)
* cada objeto tiene sus propias propiedades
* la herencia: sirve para que hereden propiedades de otra clase
* polimorfismo: nos permite modificar un metodo heredado en mi nueva clase
* UNA CLASE ES UNA CLASIFICACION, es una estructura estatica, no se modifica en el trascurso del programa.
  |-> las clases generan objetos.
  |-> puedo tener muchos objetos generados sobre una clase.
  |-> para crear una clase devemos hacer [modificador] class (palabra reservada) nombre de la clase.*/
