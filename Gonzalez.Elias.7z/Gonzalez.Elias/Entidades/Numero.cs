﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Numero
    {
                                        
        private double numero;
        /// <summary>
        /// constructor setea el valor inicial a 0.
        /// </summary>
        public Numero()
        {

        }
        /// <summary>
        /// constructor setea el valor por parametro a un string.
        /// </summary>
        /// <param name="stNum">string a asignar</param>
        public Numero(string stNum)
        {
            this.setNumero(stNum);
        }
        /// <summary>
        /// constructor setea el valor por parametro a un double.
        /// </summary>
        /// <param name="num">double a asignar</param>
        public Numero(double num)
        {
            this.numero = num;
        }
        /// <summary>
        /// setea un numero en la variable numero.
        /// </summary>
        /// <param name="stNum">string que asignar</param>
        public void setNumero(string stNum)
        {
            double nuevoNum;
            nuevoNum = this.validarNumero(stNum);
            if (nuevoNum != 0)
                this.numero = nuevoNum;
            else
                this.numero = 0;
        }
        /// <summary>
        /// obtiene el valor del objeto.
        /// </summary>
        /// <returns>devuelve un double</returns>
        public double getNumero()
        {
            return this.numero;

        }

        public static Numero operator +(Numero num1, Numero num2)
        {
            double numero;

            numero = num1.numero + num2.numero;
            Numero retorno = new Numero(numero);

            return retorno;
        }
        public static Numero operator -(Numero num1, Numero num2)
        {
            double numero;

            numero = num1.numero - num2.numero;
            Numero retorno = new Numero(numero);

            return retorno;
        }
        public static Numero operator /(Numero num1, Numero num2)
        {
            double numero;

            numero = num1.numero / num2.numero;
            Numero retorno = new Numero(numero);

            return retorno;
        }
        public static Numero operator *(Numero num1, Numero num2)
        {
            double numero;

            numero = num1.numero * num2.numero;
            Numero retorno = new Numero(numero);

            return retorno;
        }
        /// <summary>
        /// realiza la validacion de un numero ingresado.
        /// </summary>
        /// <param name="numero">string</param>
        /// <returns>retona un numero double</returns>
        private double validarNumero(string numero)
        {
            double retorno;

            if (!double.TryParse(numero, out retorno))
                retorno = 0;

            return retorno;
        }
        /// <summary>
        /// convierte un numero de decimal a binario.
        /// </summary>
        /// <param name="num">double</param>
        /// <returns>retorna el numero en binario</returns>
        public static string decimalBinario(double num)
        {
            string binario = "";
            int numero = Convert.ToInt32(num);

            while (numero > 0)
            {
                binario = numero % 2 + binario;
                numero = numero / 2;

            }
            return binario;
        }
        /// <summary>
        /// 
        /// convierte un numero string a binario.
        /// </summary>
        /// <param name="num">string</param>
        /// <returns>retorna el numero en binario</returns>
        public static string decimalBinarioStr(string num)
        {
            string binario = "";
            double numero = Convert.ToDouble(num);
            binario = Numero.decimalBinario(numero);

            return binario;
        }
        /// <summary>
        /// convierte un numero binario a decimal.
        /// </summary>
        /// <param name="numero">striing</param>
        /// <returns>retona el numero como string</returns>
        public static string binarioDecimal(string numero)
        {
            string resp;
            int respuesta = 0;
            int residuo = 0;
            int exponente = 0;
            int num = Convert.ToInt32(numero);

            do
            {
                residuo = num % 10;
                num = num / 10;
                respuesta += (int)(residuo * Math.Pow(2, exponente));
                exponente++;

            } while (num != 0);

            resp = Convert.ToString(respuesta);

            return resp;
        }
    }
}

