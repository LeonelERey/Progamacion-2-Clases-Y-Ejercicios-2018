using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Calculadora
    {
        /// <summary>
        /// valida que la operacion asignada exista.
        /// </summary>
        /// <param name="operador">string a validar</param>
        /// <returns>retorna la operacion validada y en caso contrario la operacion '+'</returns>
        private static string validarOperacion(string operador)
        {
            string retorno = "+";
            if (operador != "+")
            {
                if (operador == "-")
                    retorno = "-";
                else
                    if (operador == "*")
                    retorno = "*";
                else
                        if (operador == "/")
                    retorno = "/";
            }
            return retorno;
        }
        /// <summary>
        /// Realiza la opercion asignada entre dos numeros.
        /// </summary>
        /// <param name="num1">Numero</param>
        /// <param name="num2">Numero</param>
        /// <param name="operador">string</param>
        /// <returns>retorna la operacion realizada</returns>
        public static double operar(Numero num1, Numero num2, string operador)
        {
            double retorno = 0;
            double numero1 = num1.getNumero();
            double numero2 = num2.getNumero();

            operador = Calculadora.validarOperacion(operador);
            if (operador == "+")
                retorno = numero1 + numero2;       
            else
                    if (operador == "-")
                retorno = numero1 - numero2;
            else
                        if (operador == "*")
                retorno = numero1 * numero2;
            else
                            if (operador == "/")
                retorno = numero1 / numero2;


            return retorno;
        }
    }
}
