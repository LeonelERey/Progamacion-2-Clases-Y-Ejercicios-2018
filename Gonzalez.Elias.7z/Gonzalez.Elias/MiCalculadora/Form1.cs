using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Entidades;

namespace MiCalculadora
{
    public partial class Form1 : Form
    {
        Numero Respuesta = new Numero();
        Numero num1 = new Numero();
        Numero num2 = new Numero();

        public Form1()
        {
            InitializeComponent();
        }
        /// <summary>
        /// cierra el programa.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        /// <summary>
        /// realiza la operacion soliciada por el usuario.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            double resp;
            string num1 = txtNumero1.Text;
            string num2 = txtNumero2.Text;
            string oper = cmbOperadores.Text;
            resp=operar(num1,num2,oper);

            lblResultado.Text = Convert.ToString(resp);
        }

        private void Operadores_SelectedIndexChanged(object sender, EventArgs e)
        {
              
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void resultado_Click(object sender, EventArgs e)
        {
        }

        private void numero1_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void numero2_TextChanged(object sender, EventArgs e)
        {
           
        }
        /// <summary>
        /// limpia todos los casilleros de la aplicacion.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void limpiar_Click(object sender, EventArgs e)
        {
            limpiar();
        }
        /// <summary>
        /// conviarte el resultado a binario.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void conberBinario_Click(object sender, EventArgs e)
        {
            string result;
            int entrada = Convert.ToInt32(lblResultado.Text);
            //double numero = Convert.ToDouble(resultadoCalcu.Text);
            if (entrada >= 0)
            {
                result = Numero.decimalBinarioStr(lblResultado.Text);
                lblResultado.Text = result;
            }
            else
            { 
                MessageBox.Show("no se puede realizar la operacion.","Error al intentar cambiar.",MessageBoxButtons.OK,MessageBoxIcon.Error);
                limpiar();
            }
            
        }
        /// <summary>
        /// convierte a decimal.
        ///
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void conberDecimal_Click(object sender, EventArgs e)
        {
            string result;

            result = Numero.binarioDecimal(lblResultado.Text);
            lblResultado.Text = result;
        }
        /// <summary>
        /// limpia todos los casilleros.
        /// </summary>
        public void limpiar()
        {
            txtNumero1.Text = "";
            txtNumero2.Text = "";
            lblResultado.Text = "00";
            cmbOperadores.Text = "Operacion";
        }
        /// <summary>
        /// realiza la opracion marcada.
        /// </summary>
        /// <param name="nume1"></param>
        /// <param name="nume2"></param>
        /// <param name="operador"></param>
        /// <returns>retona un double respuesta.</returns>
        public double operar(string nume1,string nume2, string operador)
        {
            Numero num1 = new Numero(nume1);
            Numero num2 = new Numero(nume2);
            Numero Respuesta = new Numero();

            Respuesta.setNumero(Convert.ToString(Calculadora.operar(num1, num2, operador)));
            double repu = Respuesta.getNumero();

            return repu;
        }

        private void flase(object sender, EventArgs e)
        {

        }
    }
}
