using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
  public class RobotDeCombate : Robot
  {
    private int caballosDeFuerza;
    bool lucho;

    public int CaballosDeFuerza
    {
      get
      {
        return this.caballosDeFuerza;
      }
    }
    public bool Lucho
    {
      get
      {
        return this.lucho;
      }
    }
    public RobotDeCombate() : base()
    {
      this.lucho = false;
    }
    public RobotDeCombate(int energia, string origen) : base(energia, origen)
    {
      this.lucho = false;
      this.caballosDeFuerza = 10;
    }
    public RobotDeCombate(int energia, string origen, int caballosDeFuerza) : base(energia, origen)
    {
      this.caballosDeFuerza = caballosDeFuerza;
    }
    public string servirHumanidad()
    {
      string retorno;
      if (this.Energia!=0)
      {
        this.energia -= 1;
        retorno="Robot de combate {0} - Disparando misiles.";
      }
      else
      {
        retorno="Robot de combate {0} - Sin Energia.";
      }

      return retorno;

    }
  }
  
}
