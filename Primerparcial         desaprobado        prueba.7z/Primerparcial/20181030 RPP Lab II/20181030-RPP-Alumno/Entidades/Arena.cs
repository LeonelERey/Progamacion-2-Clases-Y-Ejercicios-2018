using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
  public class Arena
  {
    int espacioDisponible;
    string nombre;
    List<RobotDeCombate> robotDeCombates;
    List<RobotSirviente> robotSirvientes;

    private Arena()
    {

    }
    public Arena(string nombre,int espacioDisponible)
    {
      this.nombre = nombre;
      this.espacioDisponible = espacioDisponible;
    }
    public string combate(RobotDeCombate robot)
    {
      string retorno="";
      foreach (RobotDeCombate item in robotDeCombates)
      {
         
        if (item.Energia!=0)
        {
          
        }
        else
        {
          retorno = "no hay combatientes.";
        }
      }
      return retorno;
    }
    public static bool operator == ()
  }
        
}
