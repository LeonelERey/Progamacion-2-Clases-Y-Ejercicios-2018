using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;

namespace Entidades
{
  public abstract class Robot
  {
    protected int capacidadEnergia;
    private int codigo;
    private int contador = 0;
    protected int energia;
    protected string origen;
    
    public int CapacidadEnergia
    {
      get
      {
        return this.capacidadEnergia;
      }
    }
    public int Codigo
    {
      get
      {
        return this.codigo;
      }
    }
    public int Energia
    {
      get
      {
        return this.energia;
      }
    }
    public virtual bool CargarEnergia(int energia)
    {
      bool retorno = false;

      if (energia > 0 && energia < this.capacidadEnergia)
      {
        this.energia += energia;
      }

      return retorno;
    }
    /*public abstract bool servirHumanidad
    {      
    }*/
    
    protected Robot()
    {
      this.capacidadEnergia = 50;
      this.origen = "coreano";
      this.energia = 10;
      contador += 1;
      this.codigo = contador;
    }
    public Robot(int energia,string origen)
    {
      
    }
    public static bool operator ==(Robot r1,Robot r2)
    {
      bool retorno=false;

      if(r1.codigo==r2.codigo)
      {
        retorno = true;
      }

      return retorno;
    }
    public static bool operator !=(Robot r1, Robot r2)
    {
      return !(r1 == r2);
    }

  }
}
