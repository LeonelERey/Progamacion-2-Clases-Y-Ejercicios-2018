using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
  public class RobotSirviente:Robot
  {
    public bool cargarEnergia(int energia)
    {
      bool retorno=false;
      if(this.energia==0)
      {
        this.energia = energia;
        retorno = true;
      }

      return retorno;
    }
    public string servirHumanidad()
    {
      string retorno;
      if (this.Energia != 0)
      {
        this.energia -= 1;
        retorno="haciendo masaje.";
      }
      else
      {
        retorno="sin energia.";
      }

      return retorno;
    }
    public RobotSirviente():base()
    {

    }
    public RobotSirviente(int energia,string origen):base(energia,origen)
    {

    }
  }
}
