using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class Vehiculo
    {
        protected DateTime ingreso;
        private string patente;

        public string Patente
        { 
            get
            {
                
                if (this.patente.Length == 6)
                    return this.patente;
                else
                    return "";

            }
            set
            {
                if (this.patente.Length == 6)
                {

                    this.patente = value;
                }

            }
        }

        public Vehiculo(string patente)
        {
            this.ingreso = DateTime.Now.AddHours(-3);
            this.patente = patente;
        }
        public override string ToString()
        {
            string retorno = "Patente {0}";
            retorno = string.Format(retorno, this.patente);

            return retorno;
        }
        public virtual string ImprimirTiket()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("{0}\nIngreso :{1} ", this.ToString(), this.ingreso.ToString());
            return sb.ToString();

        }

        public static bool operator ==(Vehiculo v1, Vehiculo v2)
        {
            bool retorno = false;
            if (Equals(v1,v2) && v1.Patente == v2.Patente)
            {
                retorno = true;
            }
     
            return retorno;
        }

        public static bool operator !=(Vehiculo v1, Vehiculo v2)
        {
            return !(v1 == v2);
        }

        public abstract string ConsultarDatos();
    }
}
