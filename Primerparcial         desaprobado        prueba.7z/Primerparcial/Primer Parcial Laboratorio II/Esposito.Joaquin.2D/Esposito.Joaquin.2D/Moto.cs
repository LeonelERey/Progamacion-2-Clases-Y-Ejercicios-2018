using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Moto : Vehiculo
    {
        private int cilindrada;
        private short ruedas;
        private static int valorHora;

        static Moto() 
        {
            valorHora = 30;
        }
        public Moto(string patente, int cilindrada) :base(patente)
        {
            this.cilindrada = cilindrada;
            //valorHora = 30;
        }
        public Moto(string patente, int cilindrada, short ruedas) : this(patente, cilindrada)
        {
            this.ruedas = ruedas;
        }
        public Moto(string patente, int cilindrada, short ruedas, int valorH) : this(patente, cilindrada, ruedas)
        {
            valorHora = valorH;
        }

        public override string ConsultarDatos()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("\nCilindrada:{0}\nValor Hora:{1}\nPatente:{2}\n", this.cilindrada, valorHora, base.Patente);
            return sb.ToString();
        }
        public override bool Equals(object obj)
        {
            bool retorno = false;
            if (this.GetType() == obj.GetType())
            {
                retorno = true;
            }

            return retorno;
        }
        public override string ImprimirTiket()
        {
            Double costoEstadia;
           
            costoEstadia = ((DateTime.Now - this.ingreso).TotalHours * valorHora);


            return "MOTO\n"+base.ImprimirTiket() + " " + this.ConsultarDatos() + " " + "Costo de estadia: " + costoEstadia.ToString() + "\n";
        }
    }
}
