using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Estacionamiento
    {
        private int espacioDisponible;
        private string nombre;
        private List<Vehiculo> vehiculos;

        private Estacionamiento()
        {
            this.vehiculos = new List<Vehiculo>();
        }
        public Estacionamiento(string nombre, int espacioDisponible) : this()
        {
            this.nombre = nombre;
            this.espacioDisponible = espacioDisponible;
        }
        public static explicit operator string(Estacionamiento e)
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("Nombre:{0}\nEstacionamineto Disponible: {1}", e.nombre, e.espacioDisponible);
            sb.AppendLine("\n Vehiculos: \n");
            foreach (Vehiculo item in e.vehiculos)
            {
                sb.AppendFormat("\n{0}", item.ConsultarDatos());
            }
            return sb.ToString();
        }
        public static Estacionamiento operator +(Estacionamiento est, Vehiculo vehiculo)
        {

            if (est != vehiculo&& est.espacioDisponible>est.vehiculos.Count&&vehiculo.Patente!="")
            {
                est.vehiculos.Add(vehiculo);
            }
           


            return est;
        }
        public static string operator -(Estacionamiento est, Vehiculo vehiculo)
        {
            bool flag = false;
            string retorno;
            for (int i = 0; i < est.vehiculos.Count; i++)
            {
                if (vehiculo == est.vehiculos[i])
                {
                    est.vehiculos.Remove(vehiculo);

                    flag = true;
                }

            }
            if (flag)
                retorno = vehiculo.ImprimirTiket();
            else
                retorno = "El veh�culo no es parte del estacionamiento";
            return retorno;
        }
        public static bool operator ==(Estacionamiento est, Vehiculo vehiculo)
        {
            bool retorno = false;
            if (!Object.ReferenceEquals(vehiculo, null) && !Object.ReferenceEquals(est, null))
            {
                foreach (Vehiculo item in est.vehiculos)
                {
                    if (vehiculo == item)
                    {
                        retorno = true;
                    }

                }
            }

            return retorno;
        }

        public static bool operator !=(Estacionamiento est, Vehiculo vehiculo)
        {
            return !(est == vehiculo);
        }


    }
}
