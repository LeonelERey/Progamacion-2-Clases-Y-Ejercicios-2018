using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
 public class Pickup:Vehiculo
  {
    private string modelo;
    private  int valorHora;

    private Pickup(string patente):base(patente)
    {
      this.valorHora = 70;
    }
    public Pickup(string patente,string modelo):this(patente)
    {
      this.modelo = modelo;
    }
    public Pickup(string patente, string modelo, int valorHora) : this(patente,modelo)
    {
      this.valorHora = valorHora;
    }
    public override string ConsultarDatos()
    {
      StringBuilder sb = new StringBuilder();
      sb.AppendFormat("\nModelo: {0}\nValor Hora: {1}\nPatente: {2}\n", this.modelo, this.valorHora,base.Patente);
      return sb.ToString();
    }
        public override string ImprimirTiket()
        {
            Double costoEstadia;

            costoEstadia = ((DateTime.Now - this.ingreso).TotalHours * valorHora);


            return "PIKUP\n" +base.ImprimirTiket() + " " + this.ConsultarDatos() + " " + "Costo de estadia: " + costoEstadia.ToString()+"\n";
        }
        public override bool Equals(object obj)
    {
           bool retorno=false;
          if(this.GetType()==obj.GetType())
            {
                retorno = true;
            }

            return retorno; 
    }
        
  }
}
