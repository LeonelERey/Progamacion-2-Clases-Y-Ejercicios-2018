using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
  public class Automovil: Vehiculo
  {
    private ConsoleColor color;
    private static int valorHora;

    static Automovil()
    {
            valorHora = 50;
    }
    public Automovil(string patente, ConsoleColor color):base(patente)
    {
      this.color = color;
     
    }
    public Automovil(string patente, ConsoleColor color, int valorH):this(patente,color)
    {
      valorHora = valorH;
    }
    public override string ConsultarDatos()
    {
      StringBuilder sb = new StringBuilder();
      sb.AppendFormat("\nPatente: {0}\nColor: {1}\nValor Hora: {2}\n", base.Patente, this.color, valorHora);

      return sb.ToString();
    }
        public override bool Equals(object obj)
        {
            bool retorno = false;
            if (this.GetType() == obj.GetType())
            {
                retorno = true;
            }

            return retorno;
        }
        public override string ImprimirTiket()
        {
            Double costoEstadia;

            costoEstadia = ((DateTime.Now - this.ingreso).TotalHours * valorHora);


            return "AUTO\n"+base.ImprimirTiket() + " " + this.ConsultarDatos() + " " + "Costo de estadia: " + costoEstadia.ToString() + "\n";
        }
    }
}
